export type IconPrefix = "fas" | "fab" | "far" | "fal" | "fad";
export type IconPathData = string | string[]

export interface IconLookup {
  prefix: IconPrefix;
  // IconName is defined in the code that will be generated at build time and bundled with this file.
  iconName: IconName;
}

export interface IconDefinition extends IconLookup {
  icon: [
    number, // width
    number, // height
    string[], // ligatures
    string, // unicode
    IconPathData // svgPathData
  ];
}

export interface IconPack {
  [key: string]: IconDefinition;
}

export type IconName = 'arrow-alt-down' | 
  'arrow-alt-up' | 
  'arrows-h' | 
  'arrows-v' | 
  'check' | 
  'circle' | 
  'clock' | 
  'clone' | 
  'cog' | 
  'compress-arrows-alt' | 
  'eject' | 
  'expand-arrows-alt' | 
  'eye' | 
  'eye-slash' | 
  'film-alt' | 
  'folder-open' | 
  'hand-paper' | 
  'image' | 
  'music' | 
  'pause' | 
  'pencil' | 
  'play' | 
  'plus' | 
  'save' | 
  'sliders-v' | 
  'stop' | 
  'text' | 
  'times' | 
  'trash-alt' | 
  'video' | 
  'volume' | 
  'volume-down' | 
  'volume-mute' | 
  'wrench';
