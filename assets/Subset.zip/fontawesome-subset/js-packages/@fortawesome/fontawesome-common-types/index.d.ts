export type IconPrefix = "fas" | "fab" | "far" | "fal" | "fad";
export type IconPathData = string | string[]

export interface IconLookup {
  prefix: IconPrefix;
  // IconName is defined in the code that will be generated at build time and bundled with this file.
  iconName: IconName;
}

export interface IconDefinition extends IconLookup {
  icon: [
    number, // width
    number, // height
    string[], // ligatures
    string, // unicode
    IconPathData // svgPathData
  ];
}

export interface IconPack {
  [key: string]: IconDefinition;
}

export type IconName = 'arrow-alt-down' | 
  'arrow-alt-up' | 
  'check' | 
  'circle' | 
  'clock' | 
  'clone' | 
  'cog' | 
  'eject' | 
  'eye' | 
  'eye-slash' | 
  'folder-open' | 
  'music' | 
  'pause' | 
  'play' | 
  'plus' | 
  'redo' | 
  'save' | 
  'sliders-h' | 
  'stop' | 
  'text' | 
  'times' | 
  'trash-alt' | 
  'video' | 
  'volume' | 
  'volume-down' | 
  'volume-mute';
